const express = require('express');
const router = express.Router();
const dbConn = require('./db.js');

const isAdmin = (req, res, next) => {
    // Your isAdmin middleware code (similar to the one in the inventory.js file)
    // ...

    req.decoded = { role: 'admin' }; // Replace this with your actual decoded token
    next();
};

// Get all alerts (admin only)
router.get('/alerts', isAdmin, (req, res) => {
    const sqlQuery = "SELECT * FROM alerts";
    dbConn.query(sqlQuery, (error, results) => {
        if (error) {
            console.log(error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }

        res.status(200).json({ success: true, alerts: results, user: req.decoded });
    });
});

module.exports = router;
