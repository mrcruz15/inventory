const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const dbConn = require('./db.js');

router.post('/signup', (req, res, next) => {
    const fullName = req.body.fullName;
    const username = req.body.username;
    const password = req.body.password;
    const role = req.body.role;

    try {
        const sqlQuery = "INSERT INTO user(fullName, username, password, role) VALUES (?, ?, ?, ?)";
        dbConn.query(sqlQuery, [fullName, username, password, role], function (error, results) {
            console.log(results);
            if (error) {
                console.log(error);
                return res.status(500).json({ success: false, message: 'Internal server error' });
            }

            res.status(200).json({ success: true });
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

router.post('/signin', (req, res, next) => {
    const username = req.body.username;
    const password = req.body.password;

    try {
        const sqlQuery = "SELECT * FROM user WHERE username = ? AND password = ?";
        dbConn.query(sqlQuery, [username, password], function (error, results) {
            if (error) {
                console.log(error);
                return res.status(500).json({ success: false, message: 'Internal server error' });
            }

            if (results.length > 0) {
                const user = results[0];
                const fullName = user.fullName;
                const userID = user.userID;
                const userRole = user.role;

                const token = jwt.sign({ id: userID, username: username, fullName: fullName, role: userRole }, 'your_secret_key', { expiresIn: '1h' });

                res.status(200).json({ success: true, token: token, fullName: fullName, username: username, role: userRole });
            } else {
                res.status(401).json({ success: false, message: 'Invalid username or password' });
            }
        });
    } catch (error) {
        console.log(error);
        return res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

module.exports = router;
