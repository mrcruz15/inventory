const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const dbConn = require('./db.js');
const alertRouter = require('./alerts.js');

const isAdmin = (req, res, next) => {
    const authorizationHeader = req.headers.authorization;

    if (!authorizationHeader) {
        return res.status(401).json({ success: false, message: 'Unauthorized: Token not provided' });
    }

    const [bearer, token] = authorizationHeader.split(' ');

    if (bearer.toLowerCase() !== 'bearer' || !token) {
        return res.status(401).json({ success: false, message: 'Unauthorized: Invalid token format' });
    }

    jwt.verify(token, 'your_secret_key', (err, decoded) => {
        if (err) {
            console.log(err);
            return res.status(401).json({ success: false, message: 'Unauthorized: Invalid token' });
        }

        console.log('Decoded Token:', decoded);

        if (decoded.role !== 'admin') {
            return res.status(403).json({ success: false, message: 'Forbidden: Only admin users can access this resource' });
        }

        req.decoded = decoded;
        next();
    });
};

// Get all inventory items (admin only)
router.get('/inventory', isAdmin, (req, res) => {
    const sqlQuery = "SELECT * FROM inventory";
    dbConn.query(sqlQuery, (error, results) => {
        if (error) {
            console.log(error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }

        res.status(200).json({ success: true, inventory: results, user: req.decoded });
    });
});

// Add a new inventory item (admin only)
router.post('/inventory', isAdmin, (req, res) => {
    const { productID, itemName, stock, price } = req.body;

    const sqlQuery = "INSERT INTO inventory(productID, itemName, stock, price) VALUES (?, ?, ?, ?)";
    dbConn.query(sqlQuery, [productID, itemName, stock, price], (error, results) => {
        if (error) {
            console.log(error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }

        res.status(201).json({ success: true, message: 'Inventory item added successfully', user: req.decoded });
    });
});

// Update an inventory item by productID (admin only)
router.put('/inventory/:productID', isAdmin, async (req, res) => {
    const { stock } = req.body;
    const productID = req.params.productID;

    try {
        const [updateResult] = await dbConn.query("UPDATE inventory SET stock=? WHERE productID=?", [stock, productID]);

        if (updateResult.affectedRows > 0) {
            res.status(200).json({ success: true, message: 'Inventory item updated successfully', user: req.decoded });
        } else {
            res.status(404).json({ success: false, message: 'Inventory item not found' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

// Delete an inventory item by productID (admin only)
router.delete('/inventory/:productID', isAdmin, async (req, res) => {
    const productID = req.params.productID;

    try {
        const [deleteResult] = await dbConn.query("DELETE FROM inventory WHERE productID=?", [productID]);

        if (deleteResult.affectedRows > 0) {
            res.status(200).json({ success: true, message: 'Inventory item deleted successfully', user: req.decoded });
        } else {
            res.status(404).json({ success: false, message: 'Inventory item not found' });
        }
    } catch (error) {
        console.log(error);
        res.status(500).json({ success: false, message: 'Internal server error' });
    }
});

module.exports = router;
