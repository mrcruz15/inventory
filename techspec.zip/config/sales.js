const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const dbConn = require('./db.js');

const isAdmin = (req, res, next) => {
    const authorizationHeader = req.headers.authorization;

    if (!authorizationHeader) {
        return res.status(401).json({ success: false, message: 'Unauthorized: Token not provided' });
    }

    const [bearer, token] = authorizationHeader.split(' ');

    if (bearer.toLowerCase() !== 'bearer' || !token) {
        return res.status(401).json({ success: false, message: 'Unauthorized: Invalid token format' });
    }

    jwt.verify(token, 'your_secret_key', (err, decoded) => {
        if (err) {
            console.log(err);
            return res.status(401).json({ success: false, message: 'Unauthorized: Invalid token' });
        }

        console.log('Decoded Token:', decoded);

        if (decoded.role !== 'admin') {
            return res.status(403).json({ success: false, message: 'Forbidden: Only admin users can access this resource' });
        }

        req.decoded = decoded;
        next();
    });
};

// Get all sales transactions (admin only)
router.get('/sales', isAdmin, (req, res) => {
    const sqlQuery = "SELECT * FROM sales";
    dbConn.query(sqlQuery, (error, results) => {
        if (error) {
            console.log(error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }

        res.status(200).json({ success: true, sales: results, user: req.decoded });
    });
});

// Add a new sales transaction (admin only)
router.post('/sales', isAdmin, (req, res) => {
    const { productID, saleDate, quantity, totalPrice } = req.body;

    const sqlQuery = "INSERT INTO sales(productID, saleDate, quantity, totalPrice) VALUES (?, ?, ?, ?)";
    dbConn.query(sqlQuery, [productID, saleDate, quantity, totalPrice], (error, results) => {
        if (error) {
            console.log(error);
            return res.status(500).json({ success: false, message: 'Internal server error' });
        }

        // Update inventory stock
        const updateStockQuery = "UPDATE inventory SET stock = stock - ? WHERE productID = ?";
        dbConn.query(updateStockQuery, [quantity, productID], (updateError, updateResults) => {
            if (updateError) {
                console.log(updateError);
                return res.status(500).json({ success: false, message: 'Internal server error (update inventory stock)' });
            }

            res.status(201).json({ success: true, message: 'Sales transaction added successfully', user: req.decoded });
        });
    });
});

module.exports = router;
